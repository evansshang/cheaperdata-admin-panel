// Extract the logo icon only (without text and background) for use in smaller contexts
import 'package:flutter/material.dart';

class CheaperDataLogo extends StatelessWidget {
  final double size;
  final bool showText;
  
  const CheaperDataLogo({
    Key? key,
    this.size = 100.0,
    this.showText = true,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: showText ? size * 1.2 : size,
      child: Image.asset(
        showText 
            ? 'assets/branding/cheaperdata_logo_full.png'
            : 'assets/branding/cheaperdata_logo_icon_only.png',
        fit: BoxFit.contain,
      ),
    );
  }
}

class CheaperDataGradientBackground extends StatelessWidget {
  final Widget child;
  
  const CheaperDataGradientBackground({
    Key? key,
    required this.child,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF1E88E5), // Primary blue
            const Color(0xFF64B5F6), // Light blue
          ],
        ),
      ),
      child: child,
    );
  }
}

class CheaperDataTheme {
  // Primary colors
  static const Color primaryBlue = Color(0xFF1E88E5);
  static const Color lightBlue = Color(0xFF64B5F6);
  static const Color darkBlue = Color(0xFF0D47A1);
  static const Color accentGreen = Color(0xFF2E7D32);
  static const Color textWhite = Color(0xFFFAFAFA);
  
  // Get the app theme
  static ThemeData getTheme() {
    return ThemeData(
      primaryColor: primaryBlue,
      primaryColorLight: lightBlue,
      primaryColorDark: darkBlue,
      colorScheme: ColorScheme.fromSwatch().copyWith(
        primary: primaryBlue,
        secondary: accentGreen,
        background: const Color(0xFFF5F5F5),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: primaryBlue,
        foregroundColor: textWhite,
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w700,
          color: darkBlue,
        ),
        bodyLarge: TextStyle(
          fontFamily: 'Roboto',
          color: Color(0xFF424242),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryBlue,
          foregroundColor: textWhite,
        ),
      ),
    );
  }
}
