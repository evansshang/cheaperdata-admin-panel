import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class BundleService {
  // This would normally interact with a real API
  static Future<bool> purchaseDataBundle(
    String provider,
    String dataAmount,
    double price,
    String phoneNumber,
  ) async {
    // Simulate API call
    await Future.delayed(Duration(seconds: 2));
    
    // In a real implementation, this would call the actual MTN/Orange API
    // and process the payment through the wallet
    
    // Return success for demo purposes
    return true;
  }
  
  static List<Map<String, dynamic>> getMtnBundles() {
    return [
      {'amount': '500 MB', 'price': 500.0},
      {'amount': '1 GB', 'price': 1000.0},
      {'amount': '2 GB', 'price': 1800.0},
      {'amount': '5 GB', 'price': 4000.0},
    ];
  }
  
  static List<Map<String, dynamic>> getOrangeBundles() {
    return [
      {'amount': '500 MB', 'price': 500.0},
      {'amount': '1 GB', 'price': 1000.0},
      {'amount': '2 GB', 'price': 1800.0},
      {'amount': '5 GB', 'price': 4000.0},
    ];
  }
}
