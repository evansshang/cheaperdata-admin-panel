import 'package:flutter/material.dart';
import 'app_localizations.dart';
import 'wallet_model.dart';

class TransactionHistoryScreen extends StatelessWidget {
  // This would normally fetch data from Firestore
  final List<Transaction> transactions = [
    Transaction(
      type: TransactionType.deposit,
      amount: 1000,
      date: DateTime.now().subtract(Duration(days: 1)),
      status: TransactionStatus.completed,
    ),
    Transaction(
      type: TransactionType.purchase,
      amount: 500,
      date: DateTime.now().subtract(Duration(days: 2)),
      status: TransactionStatus.completed,
      details: {
        'provider': 'MTN',
        'dataAmount': '500 MB',
      },
    ),
    Transaction(
      type: TransactionType.referral,
      amount: 500,
      date: DateTime.now().subtract(Duration(days: 3)),
      status: TransactionStatus.completed,
      details: {
        'referredPhone': '+237 670000000',
      },
    ),
    Transaction(
      type: TransactionType.withdrawal,
      amount: 800,
      date: DateTime.now().subtract(Duration(days: 4)),
      status: TransactionStatus.completed,
    ),
    Transaction(
      type: TransactionType.purchase,
      amount: 1000,
      date: DateTime.now().subtract(Duration(days: 5)),
      status: TransactionStatus.completed,
      details: {
        'provider': 'Orange',
        'dataAmount': '1 GB',
      },
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              localizations.translate('transaction_history'),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: transactions.length,
              itemBuilder: (context, index) {
                final transaction = transactions[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: _getTransactionColor(transaction.type).withOpacity(0.2),
                      child: Icon(
                        _getTransactionIcon(transaction.type),
                        color: _getTransactionColor(transaction.type),
                      ),
                    ),
                    title: Text(transaction.getTypeString(context)),
                    subtitle: Text(
                      '${_formatDate(transaction.date)} · ${transaction.getStatusString(context)}',
                    ),
                    trailing: Text(
                      transaction.getFormattedAmount(),
                      style: TextStyle(
                        color: transaction.getAmountColor(),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onTap: () {
                      _showTransactionDetails(context, transaction, localizations);
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Color _getTransactionColor(TransactionType type) {
    switch (type) {
      case TransactionType.deposit:
        return Colors.green;
      case TransactionType.withdrawal:
        return Colors.red;
      case TransactionType.purchase:
        return Colors.blue;
      case TransactionType.referral:
        return Colors.purple;
    }
  }

  IconData _getTransactionIcon(TransactionType type) {
    switch (type) {
      case TransactionType.deposit:
        return Icons.add;
      case TransactionType.withdrawal:
        return Icons.remove;
      case TransactionType.purchase:
        return Icons.shopping_cart;
      case TransactionType.referral:
        return Icons.people;
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  void _showTransactionDetails(
    BuildContext context, 
    Transaction transaction,
    AppLocalizations localizations,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(localizations.translate('transaction_details')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow(
              localizations.translate('type'),
              transaction.getTypeString(context),
            ),
            SizedBox(height: 8),
            _buildDetailRow(
              localizations.translate('amount'),
              transaction.getFormattedAmount(),
            ),
            SizedBox(height: 8),
            _buildDetailRow(
              localizations.translate('date'),
              _formatDate(transaction.date),
            ),
            SizedBox(height: 8),
            _buildDetailRow(
              localizations.translate('status'),
              transaction.getStatusString(context),
            ),
            if (transaction.details != null) ...[
              SizedBox(height: 16),
              Text(
                localizations.translate('additional_details'),
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              ...transaction.details!.entries.map((entry) {
                return _buildDetailRow(
                  localizations.translate(entry.key),
                  entry.value.toString(),
                );
              }).toList(),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(localizations.translate('close')),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          '$label:',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Text(value),
      ],
    );
  }
}
