import 'package:flutter/material.dart';
import 'app_localizations.dart';
import 'wallet_model.dart';

class ReferralService {
  final String referralCode;
  final List<ReferralUser> referrals;
  final double totalEarnings;

  ReferralService({
    required this.referralCode,
    this.referrals = const [],
    this.totalEarnings = 0.0,
  });

  // This would normally interact with Firestore
  static ReferralService getMockReferralService() {
    return ReferralService(
      referralCode: 'ABC123',
      referrals: [
        ReferralUser(
          phoneNumber: '+237 670000000',
          registrationDate: DateTime.now().subtract(Duration(days: 10)),
          bonusAmount: 500,
        ),
        ReferralUser(
          phoneNumber: '+237 671111111',
          registrationDate: DateTime.now().subtract(Duration(days: 8)),
          bonusAmount: 500,
        ),
        ReferralUser(
          phoneNumber: '+237 672222222',
          registrationDate: DateTime.now().subtract(Duration(days: 6)),
          bonusAmount: 500,
        ),
        ReferralUser(
          phoneNumber: '+237 673333333',
          registrationDate: DateTime.now().subtract(Duration(days: 4)),
          bonusAmount: 500,
        ),
        ReferralUser(
          phoneNumber: '+237 674444444',
          registrationDate: DateTime.now().subtract(Duration(days: 2)),
          bonusAmount: 500,
        ),
      ],
      totalEarnings: 2500,
    );
  }

  void shareReferralCode() {
    // This would normally use a share plugin to share the referral code
    print('Sharing referral code: $referralCode');
  }
}

class ReferralUser {
  final String phoneNumber;
  final DateTime registrationDate;
  final double bonusAmount;

  ReferralUser({
    required this.phoneNumber,
    required this.registrationDate,
    required this.bonusAmount,
  });

  String getFormattedDate() {
    return '${registrationDate.day}/${registrationDate.month}/${registrationDate.year}';
  }

  String getFormattedBonus() {
    return '+${bonusAmount.toStringAsFixed(0)} XAF';
  }
}
