import 'package:flutter/material.dart';
import 'app_localizations.dart';

class WalletModel {
  double balance;
  List<Transaction> transactions;

  WalletModel({
    this.balance = 0.0,
    this.transactions = const [],
  });

  void addFunds(double amount) {
    balance += amount;
    transactions.add(
      Transaction(
        type: TransactionType.deposit,
        amount: amount,
        date: DateTime.now(),
        status: TransactionStatus.completed,
      ),
    );
  }

  bool withdrawFunds(double amount) {
    if (balance >= amount) {
      balance -= amount;
      transactions.add(
        Transaction(
          type: TransactionType.withdrawal,
          amount: amount,
          date: DateTime.now(),
          status: TransactionStatus.completed,
        ),
      );
      return true;
    }
    return false;
  }

  bool purchaseData(String provider, String dataAmount, double price) {
    if (balance >= price) {
      balance -= price;
      transactions.add(
        Transaction(
          type: TransactionType.purchase,
          amount: price,
          date: DateTime.now(),
          status: TransactionStatus.completed,
          details: {
            'provider': provider,
            'dataAmount': dataAmount,
          },
        ),
      );
      return true;
    }
    return false;
  }

  void addReferralBonus(double amount, String referredPhone) {
    balance += amount;
    transactions.add(
      Transaction(
        type: TransactionType.referral,
        amount: amount,
        date: DateTime.now(),
        status: TransactionStatus.completed,
        details: {
          'referredPhone': referredPhone,
        },
      ),
    );
  }
}

enum TransactionType {
  deposit,
  withdrawal,
  purchase,
  referral,
}

enum TransactionStatus {
  pending,
  completed,
  failed,
}

class Transaction {
  final TransactionType type;
  final double amount;
  final DateTime date;
  final TransactionStatus status;
  final Map<String, dynamic>? details;

  Transaction({
    required this.type,
    required this.amount,
    required this.date,
    required this.status,
    this.details,
  });

  String getTypeString(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    switch (type) {
      case TransactionType.deposit:
        return localizations.translate('deposit');
      case TransactionType.withdrawal:
        return localizations.translate('withdrawal');
      case TransactionType.purchase:
        return localizations.translate('purchase');
      case TransactionType.referral:
        return localizations.translate('referral_bonus');
    }
  }

  String getStatusString(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    switch (status) {
      case TransactionStatus.pending:
        return localizations.translate('pending');
      case TransactionStatus.completed:
        return localizations.translate('completed');
      case TransactionStatus.failed:
        return localizations.translate('failed');
    }
  }

  String getFormattedAmount() {
    if (type == TransactionType.deposit || type == TransactionType.referral) {
      return '+${amount.toStringAsFixed(0)} XAF';
    } else {
      return '-${amount.toStringAsFixed(0)} XAF';
    }
  }

  Color getAmountColor() {
    if (type == TransactionType.deposit || type == TransactionType.referral) {
      return Colors.green;
    } else {
      return Colors.red;
    }
  }
}
