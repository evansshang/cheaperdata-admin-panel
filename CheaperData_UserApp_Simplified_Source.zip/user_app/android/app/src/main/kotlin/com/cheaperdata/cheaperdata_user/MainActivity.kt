package com.cheaperdata.cheaperdata_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
