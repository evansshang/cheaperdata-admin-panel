import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter/material.dart';
import 'package:cheaperdata_user/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('End-to-end tests', () {
    testWidgets('Complete user journey test', (WidgetTester tester) async {
      // Start the app
      app.main();
      await tester.pumpAndSettle();

      // Verify login screen is displayed
      expect(find.text('CheaperData'), findsOneWidget);
      expect(find.byType(TextFormField), findsOneWidget);

      // Enter phone number
      await tester.enterText(find.byType(TextFormField), '+237 670000000');
      await tester.pumpAndSettle();

      // Tap verify button
      await tester.tap(find.widgetWithText(ElevatedButton, 'Verify'));
      await tester.pumpAndSettle();

      // Note: In a real integration test, we would need to handle SMS verification
      // For this example, we'll simulate successful verification and navigation to home screen

      // Verify home screen elements (this would happen after successful verification)
      // expect(find.text('Buy Data'), findsOneWidget);
      // expect(find.text('MTN Data'), findsOneWidget);
      // expect(find.text('Orange Data'), findsOneWidget);

      // Test navigation to wallet screen
      // await tester.tap(find.byIcon(Icons.account_balance_wallet));
      // await tester.pumpAndSettle();
      // expect(find.text('Balance'), findsOneWidget);

      // Test navigation to transactions screen
      // await tester.tap(find.byIcon(Icons.history));
      // await tester.pumpAndSettle();
      // expect(find.text('Transaction History'), findsOneWidget);

      // Test navigation to referrals screen
      // await tester.tap(find.byIcon(Icons.people));
      // await tester.pumpAndSettle();
      // expect(find.text('Referral Code'), findsOneWidget);

      // Test language switching
      // await tester.tap(find.byIcon(Icons.settings));
      // await tester.pumpAndSettle();
      // await tester.tap(find.text('Language'));
      // await tester.pumpAndSettle();
      // await tester.tap(find.text('Français'));
      // await tester.pumpAndSettle();
      // expect(find.text('Acheter des données'), findsOneWidget);
    });
  });
}
