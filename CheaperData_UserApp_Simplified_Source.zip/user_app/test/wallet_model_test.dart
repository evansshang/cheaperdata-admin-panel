import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:cheaperdata_user/wallet_model.dart';

// Mock class for testing
class MockTransaction extends Mock implements Transaction {}

void main() {
  group('WalletModel Tests', () {
    late WalletModel wallet;
    
    setUp(() {
      wallet = WalletModel(balance: 1000.0);
    });
    
    test('Initial balance should be correct', () {
      expect(wallet.balance, 1000.0);
      expect(wallet.transactions.length, 0);
    });
    
    test('addFunds should increase balance and add transaction', () {
      wallet.addFunds(500.0);
      
      expect(wallet.balance, 1500.0);
      expect(wallet.transactions.length, 1);
      expect(wallet.transactions[0].type, TransactionType.deposit);
      expect(wallet.transactions[0].amount, 500.0);
      expect(wallet.transactions[0].status, TransactionStatus.completed);
    });
    
    test('withdrawFunds should decrease balance when sufficient funds', () {
      bool result = wallet.withdrawFunds(500.0);
      
      expect(result, true);
      expect(wallet.balance, 500.0);
      expect(wallet.transactions.length, 1);
      expect(wallet.transactions[0].type, TransactionType.withdrawal);
      expect(wallet.transactions[0].amount, 500.0);
    });
    
    test('withdrawFunds should fail when insufficient funds', () {
      bool result = wallet.withdrawFunds(1500.0);
      
      expect(result, false);
      expect(wallet.balance, 1000.0);
      expect(wallet.transactions.length, 0);
    });
    
    test('purchaseData should decrease balance and add transaction', () {
      bool result = wallet.purchaseData('MTN', '1GB', 500.0);
      
      expect(result, true);
      expect(wallet.balance, 500.0);
      expect(wallet.transactions.length, 1);
      expect(wallet.transactions[0].type, TransactionType.purchase);
      expect(wallet.transactions[0].amount, 500.0);
      expect(wallet.transactions[0].details?['provider'], 'MTN');
      expect(wallet.transactions[0].details?['dataAmount'], '1GB');
    });
    
    test('addReferralBonus should increase balance and add transaction', () {
      wallet.addReferralBonus(500.0, '+237 670000000');
      
      expect(wallet.balance, 1500.0);
      expect(wallet.transactions.length, 1);
      expect(wallet.transactions[0].type, TransactionType.referral);
      expect(wallet.transactions[0].amount, 500.0);
      expect(wallet.transactions[0].details?['referredPhone'], '+237 670000000');
    });
  });
}
