import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:cheaperdata_user/bundle_service.dart';

class MockHttpClient extends Mock {
  Future<dynamic> get(Uri url) async {
    return {'success': true};
  }
  
  Future<dynamic> post(Uri url, {Object? body}) async {
    return {'success': true};
  }
}

void main() {
  group('BundleService Tests', () {
    test('getMtnBundles returns correct bundles', () {
      final bundles = BundleService.getMtnBundles();
      
      expect(bundles.length, 4);
      expect(bundles[0]['amount'], '500 MB');
      expect(bundles[0]['price'], 500.0);
      expect(bundles[1]['amount'], '1 GB');
      expect(bundles[1]['price'], 1000.0);
      expect(bundles[2]['amount'], '2 GB');
      expect(bundles[2]['price'], 1800.0);
      expect(bundles[3]['amount'], '5 GB');
      expect(bundles[3]['price'], 4000.0);
    });
    
    test('getOrangeBundles returns correct bundles', () {
      final bundles = BundleService.getOrangeBundles();
      
      expect(bundles.length, 4);
      expect(bundles[0]['amount'], '500 MB');
      expect(bundles[0]['price'], 500.0);
      expect(bundles[1]['amount'], '1 GB');
      expect(bundles[1]['price'], 1000.0);
      expect(bundles[2]['amount'], '2 GB');
      expect(bundles[2]['price'], 1800.0);
      expect(bundles[3]['amount'], '5 GB');
      expect(bundles[3]['price'], 4000.0);
    });
    
    test('purchaseDataBundle returns success for valid purchase', () async {
      final result = await BundleService.purchaseDataBundle(
        'MTN',
        '1 GB',
        1000.0,
        '+237 670000000',
      );
      
      expect(result, true);
    });
  });
}
