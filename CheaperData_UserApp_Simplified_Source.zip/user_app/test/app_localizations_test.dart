import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:cheaperdata_user/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('AppLocalizations Tests', () {
    // Mock asset bundle for testing
    final mockBundle = MockAssetBundle();
    
    setUp(() {
      // Set up mock responses for asset loading
      when(mockBundle.loadString('assets/lang/en.json')).thenAnswer((_) async => 
        json.encode({
          'app_name': 'CheaperData',
          'login': 'Login',
          'verify': 'Verify',
          'phone_number': 'Phone Number',
          'enter_phone': 'Enter your phone number',
          'buy_data': 'Buy Data',
          'wallet': 'Wallet',
          'transactions': 'Transactions',
          'referrals': 'Referrals'
        })
      );
      
      when(mockBundle.loadString('assets/lang/fr.json')).thenAnswer((_) async => 
        json.encode({
          'app_name': 'CheaperData',
          'login': 'Connexion',
          'verify': 'Vérifier',
          'phone_number': 'Numéro de téléphone',
          'enter_phone': 'Entrez votre numéro de téléphone',
          'buy_data': 'Acheter des données',
          'wallet': 'Portefeuille',
          'transactions': 'Transactions',
          'referrals': 'Parrainages'
        })
      );
    });

    test('AppLocalizations loads English translations correctly', () async {
      final localizations = await AppLocalizations.load(Locale('en'), bundle: mockBundle);
      
      expect(localizations.translate('app_name'), 'CheaperData');
      expect(localizations.translate('login'), 'Login');
      expect(localizations.translate('verify'), 'Verify');
      expect(localizations.translate('phone_number'), 'Phone Number');
    });
    
    test('AppLocalizations loads French translations correctly', () async {
      final localizations = await AppLocalizations.load(Locale('fr'), bundle: mockBundle);
      
      expect(localizations.translate('app_name'), 'CheaperData');
      expect(localizations.translate('login'), 'Connexion');
      expect(localizations.translate('verify'), 'Vérifier');
      expect(localizations.translate('phone_number'), 'Numéro de téléphone');
    });
    
    test('AppLocalizations returns key when translation is missing', () async {
      final localizations = await AppLocalizations.load(Locale('en'), bundle: mockBundle);
      
      expect(localizations.translate('non_existent_key'), 'non_existent_key');
    });
    
    test('AppLocalizations delegate loads correct locale', () async {
      final delegate = AppLocalizationsDelegate();
      
      expect(await delegate.isSupported(Locale('en')), true);
      expect(await delegate.isSupported(Locale('fr')), true);
      expect(await delegate.isSupported(Locale('es')), false);
    });
  });
}

class MockAssetBundle extends Mock implements AssetBundle {}
