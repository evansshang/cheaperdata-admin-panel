import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:cheaperdata_user/referral_service.dart';

void main() {
  group('ReferralService Tests', () {
    test('getMockReferralService returns correct data', () {
      final referralService = ReferralService.getMockReferralService();
      
      expect(referralService.referralCode, 'ABC123');
      expect(referralService.referrals.length, 5);
      expect(referralService.totalEarnings, 2500);
    });
    
    test('ReferralUser formats date correctly', () {
      final user = ReferralUser(
        phoneNumber: '+237 670000000',
        registrationDate: DateTime(2025, 5, 23),
        bonusAmount: 500,
      );
      
      expect(user.getFormattedDate(), '23/5/2025');
    });
    
    test('ReferralUser formats bonus correctly', () {
      final user = ReferralUser(
        phoneNumber: '+237 670000000',
        registrationDate: DateTime(2025, 5, 23),
        bonusAmount: 500,
      );
      
      expect(user.getFormattedBonus(), '+500 XAF');
    });
  });
}
